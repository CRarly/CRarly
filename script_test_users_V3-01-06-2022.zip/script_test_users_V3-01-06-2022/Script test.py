from openpyxl import load_workbook
from selenium import webdriver
import time
import pandas as pd

import pyautogui

import tkinter

from tkinter import *
from tkinter.filedialog import askopenfilename

Tk().withdraw()

filename = askopenfilename()

df = pd.read_excel(filename)
fd = pd.read_excel(filename)
df23 = pd.DataFrame([['Senha ok']])
df24 = pd.DataFrame([['não logou']])
df25 = pd.DataFrame([['Logou MFA']])
df26 = pd.DataFrame([['Vincular e-mail']])
df27 = pd.DataFrame([['error']])
book = load_workbook(filename)
writer = pd.ExcelWriter(filename, engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}
time.sleep(1)

i = 0
ni = 0
ni1 = 0
nd = 0
nd1 = 0
l = 1

for row in df.iterrows():

    pyautogui.click(x=94, y=83)
    time.sleep(5)
    pyautogui.write(df['OrgDefinedId'].loc[i])  # colar e-mail
    pyautogui.press({'enter'})
    time.sleep(3)
    pyautogui.write(df['Calculated Final Grade Numerator'].loc[ni])  # colar senha
    pyautogui.press({'enter'})
    time.sleep(3)
    pyautogui.press({'enter'})
    time.sleep(6)

    LogouMFA24 = pyautogui.locateOnScreen('LogouMFA.PNG')
    logou24 = pyautogui.locateOnScreen('logou.PNG')
    Vincularemail24 = pyautogui.locateOnScreen('Vincularemail.PNG')

    if not Vincularemail24 and not logou24 and not LogouMFA24:  # não logou df24
        pyautogui.click(x=1350, y=17)
        time.sleep(3)
        pyautogui.click(x=1348, y=55)
        time.sleep(3)
        pyautogui.click(x=1218, y=138)
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df24.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue
    time.sleep(6)
    LogouMFA26 = pyautogui.locateOnScreen('LogouMFA.PNG')
    logou26 = pyautogui.locateOnScreen('logou.PNG')
    Vincularemail26 = pyautogui.locateOnScreen('Vincularemail.PNG')

    if Vincularemail26 and not logou26 and not LogouMFA26:  # vincular e-mail df 26
        pyautogui.click(x=1350, y=17)
        time.sleep(3)
        pyautogui.click(x=1348, y=55)
        time.sleep(3)
        pyautogui.click(x=1218, y=138)
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df26.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue

    LogouMFA23 = pyautogui.locateOnScreen('LogouMFA.PNG')
    logou23 = pyautogui.locateOnScreen('logou.PNG')
    Vincularemail23 = pyautogui.locateOnScreen('Vincularemail.PNG')

    if not Vincularemail23 and logou23 and not LogouMFA23:  # logou df23
        pyautogui.click(x=1350, y=17)
        time.sleep(3)
        pyautogui.click(x=1348, y=55)
        time.sleep(3)
        pyautogui.click(x=1218, y=138)
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df23.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue

    LogouMFA25 = pyautogui.locateOnScreen('LogouMFA.PNG')
    logou25 = pyautogui.locateOnScreen('logou.PNG')
    Vincularemail25 = pyautogui.locateOnScreen('Vincularemail.PNG')

    if not Vincularemail25 and not logou25 and LogouMFA25:  # logouMFA df25
        #verificar erro de autenticação (inicio)
        pyautogui.click(x=383, y=406)
        time.sleep(3)
        pyautogui.press({'enter'})
        time.sleep(2)

        LogouMFA23 = pyautogui.locateOnScreen('LogouMFA.PNG')
        logou23 = pyautogui.locateOnScreen('logou.PNG')
        Vincularemail23 = pyautogui.locateOnScreen('Vincularemail.PNG')

        if not Vincularemail23 and logou23 and not LogouMFA23:  # vincular e-mail df 2
            pyautogui.click(x=1350, y=17)
            time.sleep(3)
            pyautogui.click(x=1348, y=55)
            time.sleep(3)
            pyautogui.click(x=1218, y=138)
            time.sleep(3)
            for Planilha1 in writer.sheets:
                df25.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
            writer.save()

            i += 1
            l += 1
            ni += 1
            nd += 1
            ni1 += 1
            nd1 += 1
            continue
            # verificar erro de autenticação (fim)
        LogouMFA26 = pyautogui.locateOnScreen('LogouMFA.PNG')
        logou26 = pyautogui.locateOnScreen('logou.PNG')
        Vincularemail26 = pyautogui.locateOnScreen('Vincularemail.PNG')

        if Vincularemail26 and not logou26 and not LogouMFA26:

            pyautogui.click(x=1350, y=17)
            time.sleep(3)
            pyautogui.click(x=1348, y=55)
            time.sleep(3)
            pyautogui.click(x=1218, y=138)
            time.sleep(3)
            for Planilha1 in writer.sheets:
                df26.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
            writer.save()

            i += 1
            l += 1
            ni += 1
            nd += 1
            ni1 += 1
            nd1 += 1
            continue


    # erro script df 27

    pyautogui.click(x=1350, y=17)
    time.sleep(3)
    pyautogui.click(x=1348, y=55)
    time.sleep(3)
    pyautogui.click(x=1218, y=138)
    time.sleep(3)
    for Planilha1 in writer.sheets:
        df26.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
    writer.save()

    i += 1
    l += 1
    ni += 1
    nd += 1
    ni1 += 1
    nd1 += 1
