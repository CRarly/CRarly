import pyautogui

testepg = pyautogui.locateOnScreen('testepg.PNG')
pyautogui.click ('testepg.PNG')