from openpyxl import load_workbook
from selenium import webdriver
import load_workbook
from selenium import webdriver
import time
import pandas as pd

import pyautogui
import tkinter

from tkinter import *
from tkinter.filedialog import askopenfilename

Tk().withdraw()

filename = askopenfilename()

df = pd.read_excel(filename)
fd = pd.read_excel(filename)
df23 = pd.DataFrame([['Senha ok']])
df24 = pd.DataFrame([['não logou']])
df25 = pd.DataFrame([['Logou autenticar']])
df26 = pd.DataFrame([['Vincular e-mail']])
df27 = pd.DataFrame([['Erro script']])
book = load_workbook(filename)
writer = pd.ExcelWriter(filename, engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}
time.sleep(1)

i = 0
ni = 0
ni1 = 0
nd = 0
nd1 = 0
l = 1

for row in df.iterrows():

    pyautogui.click(x=94, y=83)
    time.sleep(5)
    pyautogui.write(df['OrgDefinedId'].loc[i])  # colar e-mail
    pyautogui.press({'enter'})
    time.sleep(3)
    pyautogui.write(df['Calculated Final Grade Numerator'].loc[ni])  # colar senha
    pyautogui.press({'enter'})
    time.sleep(3)
    pyautogui.press({'enter'})
    time.sleep(6)

    LogouMFA = pyautogui.locateOnScreen('LogouMFA.PNG')
    logou = pyautogui.locateOnScreen('logou.PNG')
    Vincularemail = pyautogui.locateOnScreen('Vincularemail.PNG')

    if not Vincularemail and not logou and not LogouMFA: #não logou df24
        pyautogui.click(x=1350, y=17)
        time.sleep(3)
        pyautogui.click(x=1348, y=55)
        time.sleep(3)
        pyautogui.click(x=1218, y=138)
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df24.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue

    LogouMFA = pyautogui.locateOnScreen('LogouMFA.PNG')
    logou = pyautogui.locateOnScreen('logou.PNG')
    Vincularemail = pyautogui.locateOnScreen('Vincularemail.PNG')

    if Vincularemail and not logou and not LogouMFA: #vincular e-mail df 26
        pyautogui.click(x=1350, y=17)
        time.sleep(3)
        pyautogui.click(x=1348, y=55)
        time.sleep(3)
        pyautogui.click(x=1218, y=138)
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df26.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue

    LogouMFA = pyautogui.locateOnScreen('LogouMFA.PNG')
    logou = pyautogui.locateOnScreen('logou.PNG')
    Vincularemail = pyautogui.locateOnScreen('Vincularemail.PNG')

    if not Vincularemail and logou and not LogouMFA: # logou df23
        pyautogui.click(x=1350, y=17)
        time.sleep(3)
        pyautogui.click(x=1348, y=55)
        time.sleep(3)
        pyautogui.click(x=1218, y=138)
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df23.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue

    LogouMFA = pyautogui.locateOnScreen('LogouMFA.PNG')
    logou = pyautogui.locateOnScreen('logou.PNG')
    Vincularemail = pyautogui.locateOnScreen('Vincularemail.PNG')

    if not Vincularemail and not logou and LogouMFA: #logouMFA df25
        pyautogui.click(x=1350, y=17)
        time.sleep(3)
        pyautogui.click(x=1348, y=55)
        time.sleep(3)
        pyautogui.click(x=1218, y=138)
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df25.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue
    #erro script df 27

    pyautogui.click(x=1350, y=17)
    time.sleep(3)
    pyautogui.click(x=1348, y=55)
    time.sleep(3)
    pyautogui.click(x=1218, y=138)
    time.sleep(3)
    for Planilha1 in writer.sheets:
        df27.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
    writer.save()

    i += 1
    l += 1
    ni += 1
    nd += 1
    ni1 += 1
    nd1 += 1




