from openpyxl import load_workbook
from selenium import webdriver
import time
import pandas as pd
import pyscreeze
import pyautogui
import tkinter

from tkinter import*
from tkinter.filedialog import askopenfilename

testepg = pyautogui.click('testepg.PNG')


