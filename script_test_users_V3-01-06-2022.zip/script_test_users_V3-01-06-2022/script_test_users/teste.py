from openpyxl import load_workbook
from selenium import webdriver
import time
import pandas as pd

# using Pandas to read the xlsx file
df = pd.read_excel('rd.xlsx')
df1 = pd.DataFrame([['Enviado']])
book = load_workbook('rd.xlsx')
writer = pd.ExcelWriter('rd.xlsx', engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}

i = 0
l = 1

for row in df.iterrows():
    driver = webdriver.Chrome("C:/Users/Matheus Oliveira/Downloads/chromedriver_win32/chromedriver.exe")
    driver.get("https://conteudo.catolica.edu.br/chamados/login_user.php")
    driver.find_element_by_name("usuario").send_keys('04083664')
    driver.find_element_by_name("senha").send_keys('123456')
    driver.find_element_by_class_name("login100-form-btn").click()
    time.sleep(1)
    driver.find_element_by_link_text("Nova Solicitação").click()
    driver.find_element_by_name("matricula").send_keys(df[['Matrícula']].loc[i])
    driver.find_element_by_name("useremail").send_keys(df[['cn']].loc[i])
    driver.find_element_by_name("userphone").send_keys(df[['situ']].loc[i])
    driver.close()
    for Planilha1 in writer.sheets:
        df1.to_excel(writer, sheet_name='Planilha1', startrow=l,  startcol=6, index=False, header=False)
    writer.save()
    i += 1
    l += 1


