from openpyxl import load_workbook
from selenium import webdriver
import time
import pandas as pd

import pyautogui
import tkinter

from tkinter import*
from tkinter.filedialog import askopenfilename

Tk().withdraw()

filename = askopenfilename()


df = pd.read_excel(filename)
fd = pd.read_excel(filename)
df23 = pd.DataFrame([['ok']])
#df24 = pd.DataFrame([['Erro período']])
df25 = pd.DataFrame([['Erro disciplina']])
#df26 = pd.DataFrame([['RA inválida']])
book = load_workbook(filename)
writer = pd.ExcelWriter(filename, engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}
time.sleep(1)

i = 0
ni = 0
ni1 = 0
nd = 0
nd1= 0
l = 1
for row in df.iterrows():
    pyautogui.click(x=166, y=54)
    time.sleep(1)
    pyautogui.click(x=816, y=132)
    time.sleep(1)
    pyautogui.click(x=878, y=139)
    time.sleep(1)
    pyautogui.click(x=17, y=215)
    time.sleep(1)
    pyautogui.write(df['OrgDefinedId'].loc[i])
    pyautogui.press({'enter'})
    pyautogui.press({'enter'})
    pyautogui.click(x=366, y=215)
    pyautogui.write("2021/4", interval=0.25)
    pyautogui.press({'enter'})
    pyautogui.press({'enter'})
    pyautogui.click(x=661, y=216)
    time.sleep(1)
    pyautogui.write("103", interval=0.15)
    time.sleep(1)
    pyautogui.click(x=1227, y=214)
    time.sleep(2)
    pyautogui.click(x=1054, y=614)
    time.sleep(1)
    disc = pyautogui.locateOnScreen("disc.PNG")

    if not disc:
        pyautogui.click(x=1774, y=1000)
        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue

    pyautogui.click("disc.PNG")
    time.sleep(1)
    pyautogui.click(x=663, y=375)
    time.sleep(1)
    df1= df['Calculated Final Grade Numerator'].loc[ni]
    df2 = str(df1).replace('.', ',')
    pyautogui.write(df2)
    pyautogui.click(x=746, y=377)
    time.sleep(1)
    pyautogui.click(x=1157, y=667)
    time.sleep(3)
    pyautogui.click(x=820, y=439)
    time.sleep(1)
    pyautogui.click(x=1274, y=669)
    time.sleep(1)

    for Planilha1 in writer.sheets:
        df23.to_excel(writer, sheet_name='Notas', startrow=l,  startcol=6, index=False, header=False)
    writer.save()

    i += 1
    l += 1
    ni += 1
    nd += 1
    ni1 += 1
    nd1 += 1
"df['cod'].loc[ni] = df['cod'].str.lower()"

#period = pyautogui.locateOnScreen("period.PNG")  # não matriculado no período letivo

#if not period:
    #pyautogui.click(x=859, y=316)
    #time.sleep(2)
    #pyautogui.click(x=1263, y=666)

    #df25.to_excel(writer, sheet_name='Notas', startrow=l, startcol=6, index=False, header=False)
    #writer.save()
    #i += 1
    #l += 1
    #ni += 1
    #nd += 1
    #ni1 += 1
    #nd1 += 1

#continue
# pyautogui.click(x=1227, y=214)
# time.sleep(2)


#rainvalida = pyautogui.locateOnScreen("rainvalida.PNG")  # RA inválida

#if rainvalida:
    #pyautogui.click(x=757, y=439)
    #time.sleep(2)
    #pyautogui.press({'backspace'})
    #time.sleep(2)
    #pyautogui.click(x=1263, y=666)
    #time.sleep(1)

    #df26.to_excel(writer, sheet_name='Notas', startrow=l, startcol=6, index=False, header=False)
    #writer.save()
    #i += 1
    #l += 1
    #ni += 1
    #nd += 1
    #ni1 += 1
    #nd1 += 1


#else: