from openpyxl import load_workbook
from selenium import webdriver
import time
import pandas as pd
import pyautogui
import tkinter

from tkinter import*
from tkinter.filedialog import askopenfilename





Tk().withdraw()

filename = askopenfilename()


df = pd.read_excel(filename)
fd = pd.read_excel(filename)
df23 = pd.DataFrame([['OK']])
#df24 = pd.DataFrame([['Erro período']])
df25 = pd.DataFrame([['Erro disciplina']])
#df26 = pd.DataFrame([['RA inválida']])
book = load_workbook(filename)
writer = pd.ExcelWriter(filename, engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}
time.sleep(1)

i = 0
ni = 0
ni1 = 0
nd = 0
nd1= 0
l = 1
for row in df.iterrows():
    pyautogui.click(x=658, y=112)
    time.sleep(1)
    pyautogui.click(x=820, y=139)
    time.sleep(1)
    pyautogui.click(x=942, y=139)
    time.sleep(1)
    pyautogui.click(x=61, y=216)
    time.sleep(1)
    pyautogui.write(df['OrgDefinedId'].loc[i])
    pyautogui.press({'enter'})
    pyautogui.press({'enter'})
    time.sleep(1)
    pyautogui.click(x=383, y=217)
    time.sleep(1)
    pyautogui.write("2021/4", interval=0.05)
    pyautogui.click(x=677, y=217)
    time.sleep(1)
    pyautogui.write("103", interval=0.05)
    time.sleep(1)
    pyautogui.click(x=1239, y=214)
    time.sleep(2)

    disc = pyautogui.locateOnScreen("disc.PNG")  # Erro disciplina

    if not disc:
        pyautogui.click(x=1263, y=666)

        df25.to_excel(writer, sheet_name='Notas', startrow=l, startcol=6, index=False, header=False)
        writer.save()
        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1


    continue

    pyautogui.click("disc.PNG")
    time.sleep(1)
    pyautogui.click(x=669, y=376)
    time.sleep(1)
    df1 = df['Calculated Final Grade Numerator'].loc[ni]
    df2 = str(df1).replace('.',',')
    pyautogui.write(df2)
    pyautogui.click(x=708, y=354)
    time.sleep(1)
    pyautogui.click(x=1144, y=666)
    time.sleep(3)
    pyautogui.click(x=813, y=441)
    time.sleep(1)
    pyautogui.click(x=1266, y=665)
    time.sleep(1)


    for Planilha1 in writer.sheets:
        df23.to_excel(writer, sheet_name='Notas', startrow=l,  startcol=6, index=False, header=False)
    writer.save()

    i += 1
    l += 1
    ni += 1
    nd += 1
    ni1 += 1
    nd1 += 1
"df['cod'].loc[ni] = df['cod'].str.lower()"


