import pandas as pd
from openpyxl import load_workbook

df = pd.DataFrame(data={'Dados1': ['ok']})

#carrego o Excel com o template pré-formatado 'template.xlsx'
book = load_workbook('rd.xlsx')

#defino o writer para escrever em um novo arquivo 'arquivo_editado.xlsx'
writer = pd.ExcelWriter('rd.xlsx', engine='openpyxl')

#incluo a formatação no writer
writer.book = book
writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

#Escrevo com o .to_excel() do pandas
df.to_excel(writer,'Planilha1')

# para escrever só os valores em um lugar específico:
df.to_excel(writer, 'Planilha1', startrow=1, startcol=6, header=False, index=False)

writer.save()