from openpyxl import load_workbook
from selenium import webdriver
import time
import pandas as pd

import pyautogui
import tkinter

from tkinter import*
from tkinter.filedialog import askopenfilename

Tk().withdraw()

filename = askopenfilename()


df = pd.read_excel(filename)
fd = pd.read_excel(filename)
df23 = pd.DataFrame([['Senha ok']])
df24 = pd.DataFrame([['Erro e-mail']])
df25 = pd.DataFrame([['Erro senha']])
df26 = pd.DataFrame([['E-mail inválido']])
book = load_workbook(filename)
writer = pd.ExcelWriter(filename, engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}
time.sleep(1)

i = 0
ni = 0
ni1 = 0
nd = 0
nd1= 0
l = 1
for row in df.iterrows():

    pyautogui.click(x=166, y=54)
    time.sleep(1)
    pyautogui.write("https://ava.catolica.edu.br/d2l/login", interval=0.05)
    pyautogui.press({'enter'})
    time.sleep(2)
    pyautogui.click('Micro.PNG')
    time.sleep(2)

    mais = pyautogui.locateOnScreen('mais.PNG')

    if mais:
        pyautogui.click('mais.PNG')
        time.sleep(1)

        pyautogui.write(df['OrgDefinedId'].loc[i])  # colar e-mail
        pyautogui.press({'enter'})
        time.sleep(2)
        pyautogui.write(df['Calculated Final Grade Numerator'].loc[ni])  #colar senha
        pyautogui.press({'enter'})
        time.sleep(3)


        errosenha = pyautogui.locateOnScreen('erro_senha.PNG')

        if not errosenha:
            pyautogui.click('nao_salvar.PNG')
            time.sleep(5)
            pyautogui.click(x=1072, y=185)
            time.sleep(5)
            pyautogui.click(x=1091, y=148)
            time.sleep(5)


            nlocal = pyautogui.locateOnScreen('email_não_loc.PNG')
            if nlocal:
                for Planilha1 in writer.sheets:
                    df23.to_excel(writer, sheet_name='Notas', startrow=l, startcol=6, index=False, header=False)
                writer.save()

                i += 1
                l += 1
                ni += 1
                nd += 1
                ni1 += 1
                nd1 += 1

                continue
            time.sleep(2)
            pyautogui.click('logout.PNG')
            time.sleep(2)
            for Planilha1 in writer.sheets:
                df23.to_excel(writer, sheet_name='Notas', startrow=l, startcol=6, index=False, header=False)
            writer.save()

            i += 1
            l += 1
            ni += 1
            nd += 1
            ni1 += 1
            nd1 += 1

            continue

    for Planilha1 in writer.sheets:
        df25.to_excel(writer, sheet_name='Notas', startrow=l,  startcol=6, index=False, header=False)
    writer.save()

    i += 1
    l += 1
    ni += 1
    nd += 1
    ni1 += 1
    nd1 += 1
"df['cod'].loc[ni] = df['cod'].str.lower()"

#period = pyautogui.locateOnScreen("period.PNG")  # não matriculado no período letivo

#if not period:
    #pyautogui.click(x=859, y=316)
    #time.sleep(2)
    #pyautogui.click(x=1263, y=666)

    #df25.to_excel(writer, sheet_name='Notas', startrow=l, startcol=6, index=False, header=False)
    #writer.save()
    #i += 1
    #l += 1
    #ni += 1
    #nd += 1
    #ni1 += 1
    #nd1 += 1

#continue
# pyautogui.click(x=1227, y=214)
# time.sleep(2)


#rainvalida = pyautogui.locateOnScreen("rainvalida.PNG")  # RA inválida

#if rainvalida:
    #pyautogui.click(x=757, y=439)
    #time.sleep(2)
    #pyautogui.press({'backspace'})
    #time.sleep(2)
    #pyautogui.click(x=1263, y=666)
    #time.sleep(1)

    #df26.to_excel(writer, sheet_name='Notas', startrow=l, startcol=6, index=False, header=False)
    #writer.save()
    #i += 1
    #l += 1
    #ni += 1
    #nd += 1
    #ni1 += 1
    #nd1 += 1


#else: