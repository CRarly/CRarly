from openpyxl import load_workbook
from selenium import webdriver
import time
import pandas as pd

import pyautogui
import tkinter

from tkinter import *
from tkinter.filedialog import askopenfilename

Tk().withdraw()

filename = askopenfilename()

df = pd.read_excel(filename)
fd = pd.read_excel(filename)
df23 = pd.DataFrame([['Senha ok']])
df24 = pd.DataFrame([['não logou']])
df25 = pd.DataFrame([['Logou autenticar']])
df26 = pd.DataFrame([['Vincular e-mail']])
book = load_workbook(filename)
writer = pd.ExcelWriter(filename, engine='openpyxl')
writer.book = book
writer.sheets = {ws.title: ws for ws in book.worksheets}
time.sleep(1)

i = 0
ni = 0
ni1 = 0
nd = 0
nd1 = 0
l = 1

for row in df.iterrows():

    pyautogui.click(x=94, y=83)
    time.sleep(5)
    pyautogui.write(df['OrgDefinedId'].loc[i])  # colar e-mail
    pyautogui.press({'enter'})
    time.sleep(3)
    pyautogui.write(df['Calculated Final Grade Numerator'].loc[ni])  # colar senha
    pyautogui.press({'enter'})
    time.sleep(3)
    pyautogui.press({'enter'})
    time.sleep(6)

    logou = pyautogui.locateOnScreen('logou.PNG')
    if logou:
        pyautogui.click(x=1346, y=12)  # botão X
        time.sleep(3)
        pyautogui.click(x=1344, y=50)  # opções
        time.sleep(3)
        pyautogui.click(x=1185, y=129)  # Nova guia anônima
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df26.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue

    LogouMFA = pyautogui.locateOnScreen('LogouMFA.PNG')
    if {LogouMFA}:
        pyautogui.click(x=1346, y=12)  # botão X
        time.sleep(3)
        pyautogui.click(x=1344, y=50)  # opções
        time.sleep(3)
        pyautogui.click(x=1185, y=129)  # Nova guia anônima
        time.sleep(3)

        for Planilha1 in writer.sheets:
            df26.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue
    Vincularemail = pyautogui.locateOnScreen('Vincularemail.PNG')
    if {Vincularemail}:
        pyautogui.click(x=1346, y=12)  # botão X
        time.sleep(3)
        pyautogui.click(x=1344, y=50)  # opções
        time.sleep(3)
        pyautogui.click(x=1185, y=129)  # Nova guia anônima
        time.sleep(3)
        for Planilha1 in writer.sheets:
            df26.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
        writer.save()

        i += 1
        l += 1
        ni += 1
        nd += 1
        ni1 += 1
        nd1 += 1
        continue

    pyautogui.click(x=1350, y=17)
    time.sleep(3)
    pyautogui.click(x=1348, y=55)
    time.sleep(3)
    pyautogui.click(x=1218, y=138)
    time.sleep(3)
    for Planilha1 in writer.sheets:
        df24.to_excel(writer, sheet_name='Usuarios', startrow=l, startcol=6, index=False, header=False)
    writer.save()

    i += 1
    l += 1
    ni += 1
    nd += 1
    ni1 += 1
    nd1 += 1